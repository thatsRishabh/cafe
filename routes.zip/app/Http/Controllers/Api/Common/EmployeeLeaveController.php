<?php

namespace App\Http\Controllers\Api\Common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Str;
use App\Models\EmployeeLeave;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class EmployeeLeaveController extends Controller
{
    //
	public function employeeLeaves(Request $request)
	{
		try {
			$query = EmployeeLeave::select('*')
			->orderBy('id', 'desc');

			if (empty($request->year)) {
				$query->where('year', date('Y'));
			}
			else
			{
				$query->whereYear('year', $request->year);
			}

			if(!empty($request->employee_id))
			{
				$query->where('employee_id', $request->employee_id);
			}
			if(!empty($request->month))
			{
				$query->where('month', $request->month);
			}

			if(!empty($request->per_page_record))
			{
				$perPage = $request->per_page_record;
				$page = $request->input('page', 1);
				$total = $query->count();
				$result = $query->offset(($page - 1) * $perPage)->limit($perPage)->get();

				$pagination =  [
					'data' => $result,
					'total' => $total,
					'current_page' => $page,
					'per_page' => $perPage,
					'last_page' => ceil($total / $perPage)
				];
				$query = $pagination;
			}
			else
			{
				$query = $query->get();
			}

			return prepareResult(true,'Records Fatched Successfully' ,$query, 200);
		} catch (\Throwable $e) {
			Log::error($e);
			return prepareResult(false,'Oops! Something went wrong.' ,$e->getMessage(), 500);
		}
	}

	public function store(Request $request)
	{
		$validation = Validator::make($request->all(),  [
            'month' => 'required',
            'year' => 'required',
            'leaves' => 'required|array'           
        ]);
		if ($validation->fails()) {
			return prepareResult(false,$validation->errors()->first() ,$validation->errors(), 500);
		} 
		DB::beginTransaction();
		try {
			$eLeave_ids = [];
			foreach ($leaves as $key => $leave) {
				$eLeave = new EmployeeLeave;
				$eLeave->employee_id = $leave['employee_id'];
				$eLeave->no_of_leaves  = $leave['no_of_leaves'];
				$eLeave->month = $request->month;
				$eLeave->year = $request->year;
				$eLeave->save();
				$eLeave_ids[] = $eLeave->id;
			}
			$eLeaves = EmployeeLeave::whereIn('id',$eLeave_ids)->get();
			DB::commit();
			return prepareResult(true,'Your data has been saved successfully' , $eLeaves, 200);
		} catch (\Throwable $e) {
			Log::error($e);
			return prepareResult(false,'Oops! Something went wrong.' ,$e->getMessage(), 500);
		}
	}

	public function update(Request $request, $id)
	{
		$validation = Validator::make($request->all(), [
			'name' => 'required',
			'mobile' => 'required|numeric|digits_between:10,10|unique:users,mobile,'.$id,
			'email' => 'email|required|unique:users,email,'.$id,
			'document_number' => 'required|unique:users,document_number,'.$id,
			'designation'                   => 'required',
            'address'                       => 'required',
		]);
		if ($validation->fails()) {
			return prepareResult(false,$validation->errors()->first() ,$validation->errors(), 500);
		} 
		DB::beginTransaction();
		try {
			$user = EmployeeLeave::find($id);
			if (empty($user)) {
				return prepareResult(false,'Record not found' ,[], 500);
			}
			$user->uuid = Str::uuid();
			$user->role_id = $request->role_id;
			if($request->role_id == 5)
			{
				$user->cafe_id =  1;
			}
			$user->name = $request->name;
			$user->email  = $request->email;
			if(!empty($request->password))
			{
				$user->password =Hash::make($request->password);
			}
			$user->mobile = $request->mobile;
			$user->designation = $request->designation;
			$user->document_type = $request->document_type;
			$user->document_number = $request->document_number;
			$user->joining_date = $request->joining_date;
			$user->birth_date = $request->birth_date;
			$user->gender = $request->gender;
			$user->salary = $request->salary;
			$user->salary_balance = $request->salary_balance;
			$user->address = $request->address;

			if(!empty($request->image))
			{
				if(gettype($request->image) == "string"){
					$user->image = $request->image;
				}
				elseif ($request->hasFile('image')) {
					$file = $request->file('image');
					$filename = time().'.'.$file->getClientOriginalExtension();
					if ($file->move('assets/user_photos', $filename)) {
						$user->image = env('CDN_DOC_URL').'assets/user_photos/'.$filename.'';
					}
				}
			}
			$user->save();
			DB::commit();
			return prepareResult(true,'Your data has been Updated successfully' ,$user, 200);
		} catch (\Throwable $e) {
			Log::error($e);
			return prepareResult(false,'Oops! Something went wrong.' ,$e->getMessage(), 500);
		}
	}

	public function multipleUpdate(Request $request)
	{
		$validation = Validator::make($request->all(),  [
            'month' => 'required',
            'year' => 'required',
            'leaves' => 'required|array'           
        ]);
		if ($validation->fails()) {
			return prepareResult(false,$validation->errors()->first() ,$validation->errors(), 500);
		} 
		DB::beginTransaction();
		try {
			$eLeave_ids = [];
			foreach ($leaves as $key => $leave) {
				$eLeave = EmployeeLeave::find($leave['id']);
				if (empty($eLeave)) {
					return prepareResult(false,'Record not found' ,[], 500);
				}
				$eLeave->employee_id = $leave['employee_id'];
				$eLeave->no_of_leaves  = $leave['no_of_leaves'];
				$eLeave->month = $request->month;
				$eLeave->year = $request->year;
				$eLeave->save();
				$eLeave_ids[] = $eLeave->id;
			}
			$eLeaves = EmployeeLeave::whereIn('id',$eLeave_ids)->get();
			DB::commit();
			return prepareResult(true,'Your data has been saved successfully' , $eLeaves, 200);
		} catch (\Throwable $e) {
			Log::error($e);
			return prepareResult(false,'Oops! Something went wrong.' ,$e->getMessage(), 500);
		}
	}

	public function show($id)
	{
		try {
			$info = EmployeeLeave::find($id);
			if($info)
			{
				return prepareResult(true,'Record Fatched Successfully' ,$info, 200); 
			}
			return prepareResult(false,'Record not found' ,[], 500);
		} catch (\Throwable $e) {
			Log::error($e);
			return prepareResult(false,'Oops! Something went wrong.' ,$e->getMessage(), 500);
		}
	}

	public function destroy($id)
	{
		try {
			$info = EmployeeLeave::find($id);
			if($info)
			{
				$result = $info->delete();
				return prepareResult(true,'Record Deleted Successfully' ,$result, 200); 
			}
			return prepareResult(false,'Record Not Found' ,[], 500);
		} catch (\Throwable $e) {
			Log::error($e);
			return prepareResult(false,'Oops! Something went wrong.' ,$e->getMessage(), 500);
		}
	}

}
